import { reactive } from 'vue';

export const store = reactive({
  // 例如两个共享的变量
  polygonResult: [],
  polygonUrl: {},
  n:0,
});